import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Gamepad2, Star, Users, Trophy, Gift, Calendar, UserPlus, MessageCircle, DollarSign, Crown, Zap } from "lucide-react";
import JoinChannelModal from "./JoinChannelModal";

const GameLanding = () => {
  const registerUrl = "https://www.5diuwin.com/#/register?invitationCode=7264311604228";
  const telegramUrl = "https://t.me/Satyambabao";
  
  const [isModalOpen, setIsModalOpen] = useState(true);
  const [hasJoinedChannel, setHasJoinedChannel] = useState(false);

  const handleTelegramClick = () => {
    if (!hasJoinedChannel) {
      setIsModalOpen(true);
    } else {
      window.open(telegramUrl, '_blank');
    }
  };

  const handleConfirmJoin = () => {
    setHasJoinedChannel(true);
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
  };

  const handleRegisterClick = () => {
    window.open(registerUrl, '_blank');
  };

  const handleLoginClick = () => {
    window.open(registerUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-green-100 to-emerald-100">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-500 rounded-lg flex items-center justify-center overflow-hidden shadow-lg">
              <img 
                src="/lovable-uploads/f07d98dc-8dd8-4a88-a48e-960ca590e12d.png" 
                alt="DiuWin Logo" 
                className="w-full h-full object-cover"
              />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">DiuWin</h1>
          </div>
          <div className="flex space-x-3">
            <Button 
              variant="outline" 
              className="border-green-500 text-green-600 hover:bg-green-500 hover:text-white transition-all duration-300"
              onClick={handleLoginClick}
            >
              Login
            </Button>
            <Button 
              className="bg-gradient-to-r from-green-400 to-emerald-500 hover:from-emerald-500 hover:to-green-600 text-white font-bold transition-all duration-300"
              onClick={handleRegisterClick}
            >
              Register Now
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <div className="animate-fade-in">
          <Badge className="bg-gradient-to-r from-green-400 to-emerald-500 text-white mb-6 px-4 py-2 text-sm font-bold">
            🎰 Spin to Win Big - Play DiuWin
          </Badge>
          
          <h1 className="text-6xl md:text-8xl font-bold text-gray-800 mb-6 bg-clip-text text-transparent bg-gradient-to-r from-green-500 to-emerald-600">
            DiuWin
          </h1>
          
          <div className="relative mx-auto w-80 h-80 mb-8 animate-scale-up">
            <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-emerald-500 rounded-3xl"></div>
            <div className="relative bg-gradient-to-br from-white to-green-50 rounded-3xl p-8 m-1 flex items-center justify-center">
              <img 
                src="/lovable-uploads/f07d98dc-8dd8-4a88-a48e-960ca590e12d.png" 
                alt="DiuWin" 
                className="w-48 h-48 object-contain"
              />
            </div>
          </div>

          <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto leading-relaxed">
            Experience the ultimate slot gaming thrill with DiuWin! Spin the reels, hit the jackpot, and win massive rewards. 
            Join millions of players worldwide in the most exciting slot adventure!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg"
              className="bg-gradient-to-r from-green-400 to-emerald-500 hover:from-emerald-500 hover:to-green-600 text-white px-8 py-4 text-lg font-bold transition-all duration-300"
              onClick={handleRegisterClick}
            >
              <UserPlus className="mr-2 h-5 w-5" />
              Register & Play
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-green-500 text-green-600 hover:bg-green-500 hover:text-white px-8 py-4 text-lg font-bold transition-all duration-300"
              onClick={handleLoginClick}
            >
              <Gamepad2 className="mr-2 h-5 w-5" />
              Login Now
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="bg-white/90 border-green-200 p-6 hover:scale-105 transition-transform duration-300 shadow-lg">
            <div className="flex items-center space-x-3 mb-4">
              <Trophy className="h-8 w-8 text-green-500" />
              <h3 className="text-xl font-bold text-gray-800">Jackpot Wins</h3>
            </div>
            <p className="text-gray-600">Hit the 777 jackpot and win massive rewards! Our slot machines offer the biggest payouts with exciting bonus rounds.</p>
          </Card>

          <Card className="bg-white/90 border-green-200 p-6 hover:scale-105 transition-transform duration-300 shadow-lg">
            <div className="flex items-center space-x-3 mb-4">
              <DollarSign className="h-8 w-8 text-green-500" />
              <h3 className="text-xl font-bold text-gray-800">Commission System</h3>
            </div>
            <p className="text-gray-600">Earn commissions through our referral program. Build your network and earn passive income from every player you invite.</p>
          </Card>

          <Card className="bg-white/90 border-green-200 p-6 hover:scale-105 transition-transform duration-300 shadow-lg">
            <div className="flex items-center space-x-3 mb-4">
              <Crown className="h-8 w-8 text-green-500" />
              <h3 className="text-xl font-bold text-gray-800">VIP Rewards</h3>
            </div>
            <p className="text-gray-600">Become a senior mentor and unlock exclusive VIP benefits, higher commission rates, and special bonus rewards.</p>
          </Card>
        </div>
      </section>

      {/* Game Info Table */}
      <section className="container mx-auto px-4 py-16">
        <Card className="bg-white/90 border-green-200 overflow-hidden shadow-lg">
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Game Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg border border-green-100">
                <span className="text-gray-700 font-medium">Platform</span>
                <span className="text-gray-800 font-semibold">DiuWin</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg border border-green-100">
                <span className="text-gray-700 font-medium">Game Type</span>
                <span className="text-green-600 font-semibold">Slot Machine</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg border border-green-100">
                <span className="text-gray-700 font-medium">Status</span>
                <span className="text-gray-800 font-semibold">Live Now</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg border border-green-100">
                <span className="text-gray-700 font-medium">Invite Code</span>
                <span className="text-green-600 font-semibold">7264311604228</span>
              </div>
            </div>
          </div>
        </Card>
      </section>

      {/* Promotion Features */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-gray-800 text-center mb-12">Promotions & Rewards</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-white/90 border-green-200 p-4 text-center shadow-lg">
            <Users className="h-8 w-8 text-green-500 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-gray-800 mb-2">Subordinate Data</h3>
            <p className="text-gray-600 text-sm">Track your referrals and team performance</p>
          </Card>
          
          <Card className="bg-white/90 border-green-200 p-4 text-center shadow-lg">
            <DollarSign className="h-8 w-8 text-green-500 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-gray-800 mb-2">Commission Detail</h3>
            <p className="text-gray-600 text-sm">View your earnings and commission history</p>
          </Card>
          
          <Card className="bg-white/90 border-green-200 p-4 text-center shadow-lg">
            <Crown className="h-8 w-8 text-green-500 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-gray-800 mb-2">Senior Mentor</h3>
            <p className="text-gray-600 text-sm">Unlock VIP status and higher rewards</p>
          </Card>
          
          <Card className="bg-white/90 border-green-200 p-4 text-center shadow-lg">
            <Zap className="h-8 w-8 text-green-500 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-gray-800 mb-2">Rebate Ratio</h3>
            <p className="text-gray-600 text-sm">Get cashback on your gameplay</p>
          </Card>
        </div>
      </section>

      {/* Gift Code Section */}
      <section className="container mx-auto px-4 py-16">
        <Card className="bg-gradient-to-r from-green-400 to-emerald-500 p-8 text-center">
          <Gift className="h-16 w-16 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-4">Welcome Bonus Gift Code</h2>
          <div className="bg-white/20 rounded-lg p-4 mb-6">
            <code className="text-white text-lg font-mono font-bold">DIUWIN2025</code>
          </div>
          <p className="text-white/90 mb-6 font-semibold">Use this bonus code to get started with free spins and extra credits!</p>
          <Button 
            size="lg"
            variant="secondary"
            className="bg-white text-green-600 hover:bg-gray-100 font-bold"
            onClick={handleRegisterClick}
          >
            Claim Your Bonus
          </Button>
        </Card>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center space-y-6">
          <Button 
            size="lg"
            className="bg-gradient-to-r from-green-400 to-emerald-500 hover:from-emerald-500 hover:to-green-600 text-white px-12 py-6 text-xl font-bold transition-all duration-300"
            onClick={handleTelegramClick}
          >
            <MessageCircle className="mr-2 h-6 w-6" />
            {hasJoinedChannel ? 'Open Telegram Channel' : 'Join DiuWin VIP Telegram Channel'}
          </Button>
          
          <div className="mt-4">
            <Button 
              size="lg"
              variant="outline"
              className="border-green-500 text-green-600 hover:bg-green-500 hover:text-white px-12 py-6 text-xl font-bold transition-all duration-300"
              onClick={handleRegisterClick}
            >
              Start Playing DiuWin Now
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-800/20 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-700">Copyright © 2025 DiuWin - The Ultimate Slot Gaming Experience</p>
        </div>
      </footer>

      <JoinChannelModal 
        isOpen={isModalOpen}
        onClose={handleModalClose}
        telegramUrl={telegramUrl}
        onConfirmJoin={handleConfirmJoin}
      />
    </div>
  );
};

export default GameLanding;
