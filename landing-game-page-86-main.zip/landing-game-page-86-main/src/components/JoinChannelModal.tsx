
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { MessageCircle, CheckCircle, Star, Crown, Gift } from "lucide-react";

interface JoinChannelModalProps {
  isOpen: boolean;
  onClose: () => void;
  telegramUrl: string;
  onConfirmJoin: () => void;
}

const JoinChannelModal = ({ isOpen, onClose, telegramUrl, onConfirmJoin }: JoinChannelModalProps) => {
  const [hasJoined, setHasJoined] = useState(false);

  const handleJoinChannel = () => {
    window.open(telegramUrl, '_blank');
    setHasJoined(true);
  };

  const handleConfirmJoin = () => {
    onConfirmJoin();
    onClose();
    setHasJoined(false);
  };

  const handleClose = () => {
    onClose();
    setHasJoined(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-gradient-to-br from-white via-green-50 to-emerald-50 border-green-200 text-gray-800 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-green-500 to-emerald-600 flex items-center justify-center gap-2">
            <Crown className="h-6 w-6 text-green-500" />
            🎰 Join DiuWin VIP Channel 🎰
          </DialogTitle>
          <DialogDescription className="text-center text-gray-600 mt-4 font-semibold">
            Get exclusive slot predictions and turn ₹100 into ₹10,000 daily!
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 mt-6">
          <div className="text-center">
            <div className="text-lg mb-4 space-y-2">
              <p className="text-green-600 font-bold flex items-center justify-center gap-2">
                <Star className="h-5 w-5" />
                🔥 Why Join DiuWin VIP?
              </p>
              <div className="space-y-1 text-sm">
                <p className="flex items-center justify-start gap-2">
                  <span className="text-green-500">🎯</span>
                  Accurate slot predictions with guaranteed wins
                </p>
                <p className="flex items-center justify-start gap-2">
                  <span className="text-green-500">👥</span>
                  Active and trusted gaming community
                </p>
                <p className="flex items-center justify-start gap-2">
                  <span className="text-green-500">🎁</span>
                  Exclusive bonus codes up to ₹1000 on registration
                </p>
                <p className="flex items-center justify-start gap-2">
                  <span className="text-green-500">💎</span>
                  VIP access - Only for serious slot players!
                </p>
              </div>
            </div>
            <div className="bg-gradient-to-r from-green-400/20 to-emerald-500/20 rounded-lg p-4 border border-green-200">
              <p className="text-green-600 font-bold text-sm flex items-center justify-center gap-2">
                <Gift className="h-4 w-4" />
                👇 Click below to start winning at DiuWin 👇
              </p>
            </div>
          </div>

          {!hasJoined ? (
            <Button 
              onClick={handleJoinChannel}
              className="w-full bg-gradient-to-r from-green-400 to-emerald-500 hover:from-emerald-500 hover:to-green-600 text-white font-bold py-3 text-lg transition-all duration-300"
            >
              <MessageCircle className="mr-2 h-5 w-5" />
              🔵 Join DiuWin Telegram
            </Button>
          ) : (
            <div className="space-y-4">
              <div className="text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-2" />
                <p className="text-green-600 font-semibold">
                  Great! Now confirm that you've joined the DiuWin channel
                </p>
              </div>
              
              <Button 
                onClick={handleConfirmJoin}
                className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-3 text-lg"
              >
                <CheckCircle className="mr-2 h-5 w-5" />
                I've Joined - Start Playing
              </Button>
            </div>
          )}

          <div className="text-center">
            <Button 
              variant="outline" 
              onClick={handleClose}
              className="border-green-400 text-green-600 hover:bg-green-50"
            >
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default JoinChannelModal;
