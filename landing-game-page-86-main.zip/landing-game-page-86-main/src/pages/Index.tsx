
import GameLanding from "@/components/GameLanding";

const Index = () => {
  return <GameLanding />;
};

export default Index;
