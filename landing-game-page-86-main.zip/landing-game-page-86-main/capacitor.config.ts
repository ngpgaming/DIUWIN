
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.e1555ded94f340a0a70b7f8a79840e27',
  appName: 'BDG SLOT',
  webDir: 'dist',
  server: {
    url: "https://e1555ded-94f3-40a0-a70b-7f8a79840e27.lovableproject.com?forceHideBadge=true",
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 3000,
      backgroundColor: "#1e293b",
      showSpinner: false
    }
  }
};

export default config;
